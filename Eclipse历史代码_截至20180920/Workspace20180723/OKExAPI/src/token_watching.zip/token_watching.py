#!/usr/bin/python
# -*- coding:utf-8 -*-
# encoding:utf-8

import time
import winsound

from david_okex_http import OkexHttp
from david_qyapi_weixin import *
import datetime as dt


def sendWatchingMsg(msg='test'):
    AGENG_ID = 5
    SECRET = "nVzt0pYQWNFccZiGcpjHLKSG5TqxB6T3_KgMhqXHGMU"
    TO_USER = "david"
    TOPARTY = 4

    qy = QyWeixin()

    qy.sendtxt(SECRET, AGENG_ID, msg, TO_USER, TOPARTY)


def token_watching(token='btc_usdt', price=5988.46, direction='down'):
    """
    about : 实现的是当前价高于或低于给定的某个价位时，打印出信息，后期加上推送企业微信功能。
    """
    apikey = 'cdffc016-fdea-4e97-a200-39de74f0021a'
    apisecret = '4277FB3395F1590ABC1FC8218B8CC1DF'
    url = "https://www.okex.com/api/v1"
    http = OkexHttp(url, apikey, apisecret)
    if direction == 'down':
        if float(http.ticker(token)['ticker']['buy']) <= price:
            msg = dt.datetime.strftime(dt.datetime.now(), '%Y-%m-%d %H:%M:%S') + '\t%s\tcp:%s\twp:%s\t%s' % (
                token, http.ticker(token)['ticker']['buy'], str(price), direction)

#             sendWatchingMsg(msg)
            winsound.PlaySound("dingdong.wav", winsound.SND_ASYNC)
            print(msg)

    elif direction == 'up':
        if float(http.ticker(token)['ticker']['buy']) >= price:
            msg = dt.datetime.strftime(dt.datetime.now(), '%Y-%m-%d %H:%M:%S') + '\t%s\tcurrent_price:%s\twatching_price:%s\t%s' % (
                token, http.ticker(token)['ticker']['buy'], str(price), direction)

#             sendWatchingMsg(msg)
            winsound.PlaySound("dingdong.wav", winsound.SND_ASYNC)
            print(msg)


if __name__ == '__main__':
    """
    """
    while True:
        time.sleep(3)
        print(dt.datetime.now())
        try:
            token_watching('btc_usdt', 5994.4484, 'up')
            token_watching('btc_usdt', 5994.4484, 'down')
            token_watching('ltc_usdt', 55.0544, 'down')
            token_watching('eth_usdt', 303.8658, 'down')
            token_watching('bch_usdt', 537.1636, 'down')
            token_watching('eos_usdt', 4.8327, 'down')
            token_watching('xrp_usdt', 0.2873, 'down')
        except Exception as e:
            print(e)
            continue
